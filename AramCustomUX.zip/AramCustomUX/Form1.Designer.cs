﻿namespace AramCustomUX {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Achamp0 = new System.Windows.Forms.PictureBox();
            this.Achamp1 = new System.Windows.Forms.PictureBox();
            this.Achamp2 = new System.Windows.Forms.PictureBox();
            this.Achamp3 = new System.Windows.Forms.PictureBox();
            this.Achamp4 = new System.Windows.Forms.PictureBox();
            this.Achamp5 = new System.Windows.Forms.PictureBox();
            this.Achamp6 = new System.Windows.Forms.PictureBox();
            this.Achamp7 = new System.Windows.Forms.PictureBox();
            this.Achamp8 = new System.Windows.Forms.PictureBox();
            this.Achamp9 = new System.Windows.Forms.PictureBox();
            this.AchampLabel0 = new System.Windows.Forms.Label();
            this.AchampLabel1 = new System.Windows.Forms.Label();
            this.AchampLabel2 = new System.Windows.Forms.Label();
            this.AchampLabel3 = new System.Windows.Forms.Label();
            this.AchampLabel4 = new System.Windows.Forms.Label();
            this.AchampLabel5 = new System.Windows.Forms.Label();
            this.AchampLabel6 = new System.Windows.Forms.Label();
            this.AchampLabel7 = new System.Windows.Forms.Label();
            this.AchampLabel8 = new System.Windows.Forms.Label();
            this.AchampLabel9 = new System.Windows.Forms.Label();
            this.BchampLabel9 = new System.Windows.Forms.Label();
            this.BchampLabel8 = new System.Windows.Forms.Label();
            this.BchampLabel7 = new System.Windows.Forms.Label();
            this.BchampLabel6 = new System.Windows.Forms.Label();
            this.BchampLabel5 = new System.Windows.Forms.Label();
            this.BchampLabel4 = new System.Windows.Forms.Label();
            this.BchampLabel3 = new System.Windows.Forms.Label();
            this.BchampLabel2 = new System.Windows.Forms.Label();
            this.BchampLabel1 = new System.Windows.Forms.Label();
            this.BchampLabel0 = new System.Windows.Forms.Label();
            this.Bchamp9 = new System.Windows.Forms.PictureBox();
            this.Bchamp8 = new System.Windows.Forms.PictureBox();
            this.Bchamp7 = new System.Windows.Forms.PictureBox();
            this.Bchamp6 = new System.Windows.Forms.PictureBox();
            this.Bchamp5 = new System.Windows.Forms.PictureBox();
            this.Bchamp4 = new System.Windows.Forms.PictureBox();
            this.Bchamp3 = new System.Windows.Forms.PictureBox();
            this.Bchamp2 = new System.Windows.Forms.PictureBox();
            this.Bchamp1 = new System.Windows.Forms.PictureBox();
            this.Bchamp0 = new System.Windows.Forms.PictureBox();
            this.label18 = new System.Windows.Forms.Label();
            this.newDraftButton = new System.Windows.Forms.Button();
            this.rerollButton = new System.Windows.Forms.Button();
            this.newHumanButton = new System.Windows.Forms.Button();
            this.rerollLabel = new System.Windows.Forms.Label();
            this.rerollIcon = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.teamSizeTextBox = new System.Windows.Forms.TextBox();
            this.openBanList = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rerollIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // Achamp0
            // 
            this.Achamp0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp0.Location = new System.Drawing.Point(12, 12);
            this.Achamp0.Name = "Achamp0";
            this.Achamp0.Size = new System.Drawing.Size(100, 100);
            this.Achamp0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp0.TabIndex = 0;
            this.Achamp0.TabStop = false;
            // 
            // Achamp1
            // 
            this.Achamp1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp1.Location = new System.Drawing.Point(118, 12);
            this.Achamp1.Name = "Achamp1";
            this.Achamp1.Size = new System.Drawing.Size(100, 100);
            this.Achamp1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp1.TabIndex = 1;
            this.Achamp1.TabStop = false;
            // 
            // Achamp2
            // 
            this.Achamp2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp2.Location = new System.Drawing.Point(224, 12);
            this.Achamp2.Name = "Achamp2";
            this.Achamp2.Size = new System.Drawing.Size(100, 100);
            this.Achamp2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp2.TabIndex = 2;
            this.Achamp2.TabStop = false;
            // 
            // Achamp3
            // 
            this.Achamp3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp3.Location = new System.Drawing.Point(330, 12);
            this.Achamp3.Name = "Achamp3";
            this.Achamp3.Size = new System.Drawing.Size(100, 100);
            this.Achamp3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp3.TabIndex = 3;
            this.Achamp3.TabStop = false;
            // 
            // Achamp4
            // 
            this.Achamp4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp4.Location = new System.Drawing.Point(436, 12);
            this.Achamp4.Name = "Achamp4";
            this.Achamp4.Size = new System.Drawing.Size(100, 100);
            this.Achamp4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp4.TabIndex = 4;
            this.Achamp4.TabStop = false;
            // 
            // Achamp5
            // 
            this.Achamp5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp5.Location = new System.Drawing.Point(542, 12);
            this.Achamp5.Name = "Achamp5";
            this.Achamp5.Size = new System.Drawing.Size(100, 100);
            this.Achamp5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp5.TabIndex = 5;
            this.Achamp5.TabStop = false;
            // 
            // Achamp6
            // 
            this.Achamp6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp6.Location = new System.Drawing.Point(648, 12);
            this.Achamp6.Name = "Achamp6";
            this.Achamp6.Size = new System.Drawing.Size(100, 100);
            this.Achamp6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp6.TabIndex = 6;
            this.Achamp6.TabStop = false;
            // 
            // Achamp7
            // 
            this.Achamp7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp7.Location = new System.Drawing.Point(754, 12);
            this.Achamp7.Name = "Achamp7";
            this.Achamp7.Size = new System.Drawing.Size(100, 100);
            this.Achamp7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp7.TabIndex = 7;
            this.Achamp7.TabStop = false;
            // 
            // Achamp8
            // 
            this.Achamp8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp8.Location = new System.Drawing.Point(860, 12);
            this.Achamp8.Name = "Achamp8";
            this.Achamp8.Size = new System.Drawing.Size(100, 100);
            this.Achamp8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp8.TabIndex = 9;
            this.Achamp8.TabStop = false;
            // 
            // Achamp9
            // 
            this.Achamp9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Achamp9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Achamp9.Location = new System.Drawing.Point(966, 12);
            this.Achamp9.Name = "Achamp9";
            this.Achamp9.Size = new System.Drawing.Size(100, 100);
            this.Achamp9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Achamp9.TabIndex = 10;
            this.Achamp9.TabStop = false;
            // 
            // AchampLabel0
            // 
            this.AchampLabel0.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel0.Location = new System.Drawing.Point(12, 125);
            this.AchampLabel0.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel0.Name = "AchampLabel0";
            this.AchampLabel0.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel0.TabIndex = 11;
            this.AchampLabel0.Tag = "";
            this.AchampLabel0.Text = "Xin";
            this.AchampLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel1
            // 
            this.AchampLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel1.Location = new System.Drawing.Point(116, 125);
            this.AchampLabel1.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel1.Name = "AchampLabel1";
            this.AchampLabel1.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel1.TabIndex = 12;
            this.AchampLabel1.Tag = "";
            this.AchampLabel1.Text = "Xin Zhaoaaaaaaaaaa";
            this.AchampLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel2
            // 
            this.AchampLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel2.Location = new System.Drawing.Point(224, 125);
            this.AchampLabel2.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel2.Name = "AchampLabel2";
            this.AchampLabel2.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel2.TabIndex = 13;
            this.AchampLabel2.Tag = "";
            this.AchampLabel2.Text = "Xin";
            this.AchampLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel3
            // 
            this.AchampLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel3.Location = new System.Drawing.Point(330, 125);
            this.AchampLabel3.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel3.Name = "AchampLabel3";
            this.AchampLabel3.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel3.TabIndex = 14;
            this.AchampLabel3.Tag = "";
            this.AchampLabel3.Text = "Xin";
            this.AchampLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel4
            // 
            this.AchampLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel4.Location = new System.Drawing.Point(436, 125);
            this.AchampLabel4.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel4.Name = "AchampLabel4";
            this.AchampLabel4.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel4.TabIndex = 15;
            this.AchampLabel4.Tag = "";
            this.AchampLabel4.Text = "Xin";
            this.AchampLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel5
            // 
            this.AchampLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel5.Location = new System.Drawing.Point(539, 125);
            this.AchampLabel5.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel5.Name = "AchampLabel5";
            this.AchampLabel5.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel5.TabIndex = 16;
            this.AchampLabel5.Tag = "";
            this.AchampLabel5.Text = "Xin";
            this.AchampLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel6
            // 
            this.AchampLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel6.Location = new System.Drawing.Point(645, 125);
            this.AchampLabel6.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel6.Name = "AchampLabel6";
            this.AchampLabel6.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel6.TabIndex = 17;
            this.AchampLabel6.Tag = "";
            this.AchampLabel6.Text = "Xin";
            this.AchampLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel7
            // 
            this.AchampLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel7.Location = new System.Drawing.Point(751, 125);
            this.AchampLabel7.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel7.Name = "AchampLabel7";
            this.AchampLabel7.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel7.TabIndex = 18;
            this.AchampLabel7.Tag = "";
            this.AchampLabel7.Text = "Xin";
            this.AchampLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel8
            // 
            this.AchampLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel8.Location = new System.Drawing.Point(860, 125);
            this.AchampLabel8.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel8.Name = "AchampLabel8";
            this.AchampLabel8.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel8.TabIndex = 19;
            this.AchampLabel8.Tag = "";
            this.AchampLabel8.Text = "Xin";
            this.AchampLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // AchampLabel9
            // 
            this.AchampLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.AchampLabel9.Location = new System.Drawing.Point(967, 125);
            this.AchampLabel9.MaximumSize = new System.Drawing.Size(100, 100);
            this.AchampLabel9.Name = "AchampLabel9";
            this.AchampLabel9.Size = new System.Drawing.Size(100, 40);
            this.AchampLabel9.TabIndex = 20;
            this.AchampLabel9.Tag = "";
            this.AchampLabel9.Text = "Xin";
            this.AchampLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel9
            // 
            this.BchampLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel9.Location = new System.Drawing.Point(967, 340);
            this.BchampLabel9.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel9.Name = "BchampLabel9";
            this.BchampLabel9.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel9.TabIndex = 40;
            this.BchampLabel9.Tag = "";
            this.BchampLabel9.Text = "Xin";
            this.BchampLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel8
            // 
            this.BchampLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel8.Location = new System.Drawing.Point(860, 340);
            this.BchampLabel8.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel8.Name = "BchampLabel8";
            this.BchampLabel8.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel8.TabIndex = 39;
            this.BchampLabel8.Tag = "";
            this.BchampLabel8.Text = "Xin";
            this.BchampLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel7
            // 
            this.BchampLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel7.Location = new System.Drawing.Point(751, 340);
            this.BchampLabel7.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel7.Name = "BchampLabel7";
            this.BchampLabel7.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel7.TabIndex = 38;
            this.BchampLabel7.Tag = "";
            this.BchampLabel7.Text = "Xin";
            this.BchampLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel6
            // 
            this.BchampLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel6.Location = new System.Drawing.Point(645, 340);
            this.BchampLabel6.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel6.Name = "BchampLabel6";
            this.BchampLabel6.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel6.TabIndex = 37;
            this.BchampLabel6.Tag = "";
            this.BchampLabel6.Text = "Xin";
            this.BchampLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel5
            // 
            this.BchampLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel5.Location = new System.Drawing.Point(539, 340);
            this.BchampLabel5.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel5.Name = "BchampLabel5";
            this.BchampLabel5.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel5.TabIndex = 36;
            this.BchampLabel5.Tag = "";
            this.BchampLabel5.Text = "Xin";
            this.BchampLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel4
            // 
            this.BchampLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel4.Location = new System.Drawing.Point(436, 340);
            this.BchampLabel4.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel4.Name = "BchampLabel4";
            this.BchampLabel4.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel4.TabIndex = 35;
            this.BchampLabel4.Tag = "";
            this.BchampLabel4.Text = "Xin";
            this.BchampLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel3
            // 
            this.BchampLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel3.Location = new System.Drawing.Point(330, 340);
            this.BchampLabel3.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel3.Name = "BchampLabel3";
            this.BchampLabel3.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel3.TabIndex = 34;
            this.BchampLabel3.Tag = "";
            this.BchampLabel3.Text = "Xin";
            this.BchampLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel2
            // 
            this.BchampLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel2.Location = new System.Drawing.Point(224, 340);
            this.BchampLabel2.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel2.Name = "BchampLabel2";
            this.BchampLabel2.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel2.TabIndex = 33;
            this.BchampLabel2.Tag = "";
            this.BchampLabel2.Text = "Xin";
            this.BchampLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel1
            // 
            this.BchampLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel1.Location = new System.Drawing.Point(115, 340);
            this.BchampLabel1.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel1.Name = "BchampLabel1";
            this.BchampLabel1.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel1.TabIndex = 32;
            this.BchampLabel1.Tag = "";
            this.BchampLabel1.Text = "Xin Zhaoaaaaaaaaaa";
            this.BchampLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // BchampLabel0
            // 
            this.BchampLabel0.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BchampLabel0.Location = new System.Drawing.Point(12, 340);
            this.BchampLabel0.MaximumSize = new System.Drawing.Size(100, 100);
            this.BchampLabel0.Name = "BchampLabel0";
            this.BchampLabel0.Size = new System.Drawing.Size(100, 40);
            this.BchampLabel0.TabIndex = 31;
            this.BchampLabel0.Tag = "";
            this.BchampLabel0.Text = "Xin";
            this.BchampLabel0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Bchamp9
            // 
            this.Bchamp9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp9.Location = new System.Drawing.Point(966, 227);
            this.Bchamp9.Name = "Bchamp9";
            this.Bchamp9.Size = new System.Drawing.Size(100, 100);
            this.Bchamp9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp9.TabIndex = 30;
            this.Bchamp9.TabStop = false;
            // 
            // Bchamp8
            // 
            this.Bchamp8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp8.Location = new System.Drawing.Point(860, 227);
            this.Bchamp8.Name = "Bchamp8";
            this.Bchamp8.Size = new System.Drawing.Size(100, 100);
            this.Bchamp8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp8.TabIndex = 29;
            this.Bchamp8.TabStop = false;
            // 
            // Bchamp7
            // 
            this.Bchamp7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp7.Location = new System.Drawing.Point(754, 227);
            this.Bchamp7.Name = "Bchamp7";
            this.Bchamp7.Size = new System.Drawing.Size(100, 100);
            this.Bchamp7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp7.TabIndex = 28;
            this.Bchamp7.TabStop = false;
            // 
            // Bchamp6
            // 
            this.Bchamp6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp6.Location = new System.Drawing.Point(648, 227);
            this.Bchamp6.Name = "Bchamp6";
            this.Bchamp6.Size = new System.Drawing.Size(100, 100);
            this.Bchamp6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp6.TabIndex = 27;
            this.Bchamp6.TabStop = false;
            // 
            // Bchamp5
            // 
            this.Bchamp5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp5.Location = new System.Drawing.Point(542, 227);
            this.Bchamp5.Name = "Bchamp5";
            this.Bchamp5.Size = new System.Drawing.Size(100, 100);
            this.Bchamp5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp5.TabIndex = 26;
            this.Bchamp5.TabStop = false;
            // 
            // Bchamp4
            // 
            this.Bchamp4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp4.Location = new System.Drawing.Point(436, 227);
            this.Bchamp4.Name = "Bchamp4";
            this.Bchamp4.Size = new System.Drawing.Size(100, 100);
            this.Bchamp4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp4.TabIndex = 25;
            this.Bchamp4.TabStop = false;
            // 
            // Bchamp3
            // 
            this.Bchamp3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp3.Location = new System.Drawing.Point(330, 227);
            this.Bchamp3.Name = "Bchamp3";
            this.Bchamp3.Size = new System.Drawing.Size(100, 100);
            this.Bchamp3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp3.TabIndex = 24;
            this.Bchamp3.TabStop = false;
            // 
            // Bchamp2
            // 
            this.Bchamp2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp2.Location = new System.Drawing.Point(224, 227);
            this.Bchamp2.Name = "Bchamp2";
            this.Bchamp2.Size = new System.Drawing.Size(100, 100);
            this.Bchamp2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp2.TabIndex = 23;
            this.Bchamp2.TabStop = false;
            // 
            // Bchamp1
            // 
            this.Bchamp1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp1.Location = new System.Drawing.Point(118, 227);
            this.Bchamp1.Name = "Bchamp1";
            this.Bchamp1.Size = new System.Drawing.Size(100, 100);
            this.Bchamp1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp1.TabIndex = 22;
            this.Bchamp1.TabStop = false;
            // 
            // Bchamp0
            // 
            this.Bchamp0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Bchamp0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bchamp0.Location = new System.Drawing.Point(12, 227);
            this.Bchamp0.Name = "Bchamp0";
            this.Bchamp0.Size = new System.Drawing.Size(100, 100);
            this.Bchamp0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Bchamp0.TabIndex = 21;
            this.Bchamp0.TabStop = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label18.Location = new System.Drawing.Point(516, 165);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(48, 37);
            this.label18.TabIndex = 41;
            this.label18.Text = "vs";
            // 
            // newDraftButton
            // 
            this.newDraftButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.newDraftButton.Location = new System.Drawing.Point(476, 639);
            this.newDraftButton.Name = "newDraftButton";
            this.newDraftButton.Size = new System.Drawing.Size(125, 49);
            this.newDraftButton.TabIndex = 43;
            this.newDraftButton.Text = "New Draft";
            this.newDraftButton.UseVisualStyleBackColor = true;
            this.newDraftButton.Click += new System.EventHandler(this.newDraftButton_Click);
            // 
            // rerollButton
            // 
            this.rerollButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.rerollButton.Location = new System.Drawing.Point(542, 539);
            this.rerollButton.Name = "rerollButton";
            this.rerollButton.Size = new System.Drawing.Size(125, 49);
            this.rerollButton.TabIndex = 44;
            this.rerollButton.Text = "Reroll";
            this.rerollButton.UseVisualStyleBackColor = true;
            this.rerollButton.Click += new System.EventHandler(this.rerollButton_Click);
            // 
            // newHumanButton
            // 
            this.newHumanButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.newHumanButton.Location = new System.Drawing.Point(411, 539);
            this.newHumanButton.Name = "newHumanButton";
            this.newHumanButton.Size = new System.Drawing.Size(125, 49);
            this.newHumanButton.TabIndex = 45;
            this.newHumanButton.Text = "New Human";
            this.newHumanButton.UseVisualStyleBackColor = true;
            this.newHumanButton.Click += new System.EventHandler(this.newHumanButton_Click);
            // 
            // rerollLabel
            // 
            this.rerollLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rerollLabel.Location = new System.Drawing.Point(489, 496);
            this.rerollLabel.MaximumSize = new System.Drawing.Size(100, 100);
            this.rerollLabel.Name = "rerollLabel";
            this.rerollLabel.Size = new System.Drawing.Size(100, 40);
            this.rerollLabel.TabIndex = 47;
            this.rerollLabel.Tag = "";
            this.rerollLabel.Text = "Xin";
            this.rerollLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rerollIcon
            // 
            this.rerollIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.rerollIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rerollIcon.Location = new System.Drawing.Point(489, 393);
            this.rerollIcon.Name = "rerollIcon";
            this.rerollIcon.Size = new System.Drawing.Size(100, 100);
            this.rerollIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rerollIcon.TabIndex = 46;
            this.rerollIcon.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(11, 635);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 22);
            this.label1.TabIndex = 48;
            this.label1.Tag = "";
            this.label1.Text = "Pool size:";
            // 
            // teamSizeTextBox
            // 
            this.teamSizeTextBox.Location = new System.Drawing.Point(12, 660);
            this.teamSizeTextBox.Name = "teamSizeTextBox";
            this.teamSizeTextBox.Size = new System.Drawing.Size(100, 20);
            this.teamSizeTextBox.TabIndex = 49;
            this.teamSizeTextBox.Text = "5";
            // 
            // openBanList
            // 
            this.openBanList.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.openBanList.Location = new System.Drawing.Point(955, 639);
            this.openBanList.Name = "openBanList";
            this.openBanList.Size = new System.Drawing.Size(112, 49);
            this.openBanList.TabIndex = 50;
            this.openBanList.Text = "Ban List";
            this.openBanList.UseVisualStyleBackColor = true;
            this.openBanList.Click += new System.EventHandler(this.openBanList_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 700);
            this.Controls.Add(this.openBanList);
            this.Controls.Add(this.teamSizeTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rerollLabel);
            this.Controls.Add(this.rerollIcon);
            this.Controls.Add(this.newHumanButton);
            this.Controls.Add(this.rerollButton);
            this.Controls.Add(this.newDraftButton);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.BchampLabel9);
            this.Controls.Add(this.BchampLabel8);
            this.Controls.Add(this.BchampLabel7);
            this.Controls.Add(this.BchampLabel6);
            this.Controls.Add(this.BchampLabel5);
            this.Controls.Add(this.BchampLabel4);
            this.Controls.Add(this.BchampLabel3);
            this.Controls.Add(this.BchampLabel2);
            this.Controls.Add(this.BchampLabel1);
            this.Controls.Add(this.BchampLabel0);
            this.Controls.Add(this.Bchamp9);
            this.Controls.Add(this.Bchamp8);
            this.Controls.Add(this.Bchamp7);
            this.Controls.Add(this.Bchamp6);
            this.Controls.Add(this.Bchamp5);
            this.Controls.Add(this.Bchamp4);
            this.Controls.Add(this.Bchamp3);
            this.Controls.Add(this.Bchamp2);
            this.Controls.Add(this.Bchamp1);
            this.Controls.Add(this.Bchamp0);
            this.Controls.Add(this.AchampLabel9);
            this.Controls.Add(this.AchampLabel8);
            this.Controls.Add(this.AchampLabel7);
            this.Controls.Add(this.AchampLabel6);
            this.Controls.Add(this.AchampLabel5);
            this.Controls.Add(this.AchampLabel4);
            this.Controls.Add(this.AchampLabel3);
            this.Controls.Add(this.AchampLabel2);
            this.Controls.Add(this.AchampLabel1);
            this.Controls.Add(this.AchampLabel0);
            this.Controls.Add(this.Achamp9);
            this.Controls.Add(this.Achamp8);
            this.Controls.Add(this.Achamp7);
            this.Controls.Add(this.Achamp6);
            this.Controls.Add(this.Achamp5);
            this.Controls.Add(this.Achamp4);
            this.Controls.Add(this.Achamp3);
            this.Controls.Add(this.Achamp2);
            this.Controls.Add(this.Achamp1);
            this.Controls.Add(this.Achamp0);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Aram Random Champions";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Achamp0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Achamp9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bchamp0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rerollIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Achamp0;
        private System.Windows.Forms.PictureBox Achamp1;
        private System.Windows.Forms.PictureBox Achamp2;
        private System.Windows.Forms.PictureBox Achamp3;
        private System.Windows.Forms.PictureBox Achamp4;
        private System.Windows.Forms.PictureBox Achamp5;
        private System.Windows.Forms.PictureBox Achamp6;
        private System.Windows.Forms.PictureBox Achamp7;
        private System.Windows.Forms.PictureBox Achamp8;
        private System.Windows.Forms.PictureBox Achamp9;
        private System.Windows.Forms.Label AchampLabel0;
        private System.Windows.Forms.Label AchampLabel1;
        private System.Windows.Forms.Label AchampLabel2;
        private System.Windows.Forms.Label AchampLabel3;
        private System.Windows.Forms.Label AchampLabel4;
        private System.Windows.Forms.Label AchampLabel5;
        private System.Windows.Forms.Label AchampLabel6;
        private System.Windows.Forms.Label AchampLabel7;
        private System.Windows.Forms.Label AchampLabel8;
        private System.Windows.Forms.Label AchampLabel9;
        private System.Windows.Forms.Label BchampLabel9;
        private System.Windows.Forms.Label BchampLabel8;
        private System.Windows.Forms.Label BchampLabel7;
        private System.Windows.Forms.Label BchampLabel6;
        private System.Windows.Forms.Label BchampLabel5;
        private System.Windows.Forms.Label BchampLabel4;
        private System.Windows.Forms.Label BchampLabel3;
        private System.Windows.Forms.Label BchampLabel2;
        private System.Windows.Forms.Label BchampLabel1;
        private System.Windows.Forms.Label BchampLabel0;
        private System.Windows.Forms.PictureBox Bchamp9;
        private System.Windows.Forms.PictureBox Bchamp8;
        private System.Windows.Forms.PictureBox Bchamp7;
        private System.Windows.Forms.PictureBox Bchamp6;
        private System.Windows.Forms.PictureBox Bchamp5;
        private System.Windows.Forms.PictureBox Bchamp4;
        private System.Windows.Forms.PictureBox Bchamp3;
        private System.Windows.Forms.PictureBox Bchamp2;
        private System.Windows.Forms.PictureBox Bchamp1;
        private System.Windows.Forms.PictureBox Bchamp0;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button newDraftButton;
        private System.Windows.Forms.Button rerollButton;
        private System.Windows.Forms.Button newHumanButton;
        private System.Windows.Forms.Label rerollLabel;
        private System.Windows.Forms.PictureBox rerollIcon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox teamSizeTextBox;
        private System.Windows.Forms.Button openBanList;
    }
}

